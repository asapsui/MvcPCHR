﻿using Microsoft.AspNetCore.Mvc;

namespace MvcPCHR.Controllers
{
    public class RegisterController : Controller
    {
        //
        // GET: /Register/
        //[HttpGet]
        //[ActionName("Signup")]
        /*
        public string Index()
        {
            return "Hello from register.index";
            //return View();
        }
        */

        // POST: 
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}
